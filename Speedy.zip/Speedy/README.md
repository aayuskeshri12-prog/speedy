### Speedy Text Editor
A text editor designed to be customizable for fast keyboard shortcuts